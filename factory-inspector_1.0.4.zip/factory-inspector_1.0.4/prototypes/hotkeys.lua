data:extend({
    {
        type = "custom-input",
        name = "fi_toggle_main_dialog",
        key_sequence = "CONTROL + Q",
        consuming = "game-only",
        order = "a"
    }
})