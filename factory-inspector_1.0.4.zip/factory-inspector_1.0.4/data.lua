require("prototypes.hotkeys")
require("prototypes.shortcuts")
require("prototypes.styles")